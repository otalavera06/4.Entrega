<?php
$servername = "localhost:3306";
$username = "root";
$password = "1MG2024";
$dbname = "ML_4Entrega_EtxeberriaHodei";
 
//Konexioa sortu
$conn = new mysqli($servername, $username, $password, $dbname);
 
//Konexioa konprobatu
if ($conn->connect_error) {
    die("Konexio Errorea" . $conn->connect_error);
} else {
    echo "Ondo konektatu da";
    echo "<br>";
}
$row = "";
$izena = "";
$mota = "";
$prezioa = "";
if (isset($_GET["izena"])) {
    $izena = ($_GET["izena"]);
}
if (isset($_GET["mota"])) {
    $mota = ($_GET["mota"]);
}
if (isset($_GET["prezioa"])) {
    $prezioa = ($_GET["prezioa"]);
}
?>
 
<form action="5.2.Ariketa.php" method="get">
    <br>
    <label for="izena"> <strong>Erregistroa sartu: </strong></label>
    <br>
    <input type="text" name="izena" id="izena" value="" placeholder="sartu izena" />
    <input type="text" name="mota" id="mota" value="" placeholder="sartu mota" />
    <input type="number" name="prezioa" id="prezioa" value="" placeholder="..€">
    <button>Sartu</button>
</form>
 
<?php
 
if (isset($_GET["izena"]) && isset($_GET["mota"]) && isset($_GET["prezioa"])) {
 
    $sql = "insert into produktuak (izena, mota, prezioa) values ( '$izena', '$mota', '$prezioa');";
    if ($conn->query($sql) === TRUE) {
        echo "Insert-a ondo egin da";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
 
}
 
$conn->close();