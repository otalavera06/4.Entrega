<head>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<style>
     tr,th, td{
        border: 1px solid black;
        width: 200px;
        row-gap: 0px;
     }
     i{
        margin-left:5px;
        color:blue;
     }
</style>

<?php
$servername = "localhost:3306";
$username = "root";
$password = "1MG2024";
$dbname = "ML_4Entrega_EtxeberriaHodei";
 
//Konexioa sortu
$conn = new mysqli($servername, $username, $password, $dbname);
 
//Konexioa konprobatu
if ($conn->connect_error) {
    die("Konexio Errorea" . $conn->connect_error);
} else {
    echo "Ondo konektatu zara datu basera";
    echo "<br>";
}

?>
<a href="5.2.Ariketa.php">
<i class="fa fa-plus" aria-hidden="true"></i>
</a>
<form action="" method="get">
    <input type="text" name="bilaketa" id="bilaketa">
    <button>Bilatu</button>
</form>
<?php

$row = "";
$izena="";
if (isset($_GET["izena"])) {
    $izena = $_GET["izena"];
}
$mota="";
if (isset($_GET["mota"])) {
    $mota = $_GET["mota"];
}
$prezioa="";
if (isset($_GET["prezioa"])) {
    $prezioa = $_GET["prezioa"];
}

 
$sql = "select idProduktua, izena, mota, prezioa from produktuak";
$result = $conn->query(query: $sql);
?>
<table>
    <tr>
    <th>idProduktua</th>
    <th>Izena</th>
    <th>Mota</th>
    <th>Prezioa</th>
    <th>aldatu</th>

    </tr>
</table>
<?php
if ($result->num_rows > 0) {
    //lerro bakoitzean dagoen data begiratzeko
    while ($row = $result->fetch_assoc()) {
        
        echo "<table>";
        echo "<tr>";
        echo  "<td>". $row["idProduktua"]. "</td>". "<td>".$row["izena"]."</td>" ."<td>". $row["mota"]."</td>" . "<td>".$row["prezioa"] ."</td>"."<td>"."<i class='fa fa-pencil' aria-hidden='true'></i>"
. "<i class='fa fa-trash' aria-hidden='true'></i>"."</td>"."</tr>";
    echo"</table>";
    }
}

$conn->close();