<?php
$servername = "localhost:3306";
$username = "root";
$password = "1MG2024";
$dbname = "ml4entrega";

//Konexioa sortu
$conn = new mysqli($servername, $username, $password, $dbname);

//Konexioa konprobatu
if ($conn->connect_error) {
    die("Konexio Errorea" . $conn->connect_error);
} else {
    echo "Ondo konektatu da";
    echo "<br>";
}
$row = "";
$filtratu = "";
if (isset($_GET["bilatu"])) {
    $filtratu = ($_GET['bilatu']);
}
$izena = "";
if (isset($_GET["izena"])) {
    $izena = $_GET["izena"];
}
$mota = "";
if (isset($_GET["mota"])) {
    $mota = $_GET["mota"];
}
$prezioa = "";
if (isset($_GET["prezioa"])) {
    $prezioa = $_GET["prezioa"];
}
$id = "";
if (isset($_GET["id"])) {
    $id = $_GET["id"];
}
$aldatu = "";
if (isset($_GET["aldatu"])) {
    $aldatu = $_GET["aldatu"];
}
$izena1 = "";
if (isset($_GET["izena1"])) {
    $izena1 = $_GET["izena1"];
}
$mota1 = "";
if (isset($_GET["mota1"])) {
    $mota1 = $_GET["mota1"];
}
$prezioa1 = "";
if (isset($_GET["prezioa1"])) {
    $prezioa1 = $_GET["prezioa1"];
}
?>
<html>

<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        tr,
        th,
        td {
            border: 1px solid black;
            width: 200px;
            row-gap: 0px;
        }

        i {
            margin-left: 5px;
            color: blue;
        }
    </style>
</head>

<body>
    <form action="1.Ariketa.php" method="get">
        <br>
        <label for="izena"> <strong>Bilatu nahi duzun produktua jarri: </strong></label>
        <br>
        <form action="" method="get">
            <input type="text" name="bilatu" id="bilatu">
            <button>Bilatu</button>
        </form>

        <form action="1.Ariketa.php" method="get">
            <br>
            <label for="izena"> <strong>Sartu produktua: </strong></label>
            <br>
            <input type="text" name="izena" id="izena" value="" placeholder="sartu izena" /><br>
            <input type="text" name="mota" id="mota" value="" placeholder="sartu mota" /><br>
            <input type="number" name="prezioa" id="prezioa" value="" placeholder="..€">
            <button class="fa fa-plus" aria-hidden="true" name="gehitu" value="gehitu"></button><br><br>
        </form>
        <form action="1.Ariketa.php" method="get">
            <label for="id">Sartu kendu nahi duzun produktuaren Id-a:</label><br>
            <input type="text" name="id" id="id" placeholder="sartu Id-a" />
            <button class="fa fa-trash" aria-hidden="true" id="kendu"></button>
        </form>

        <form action="1.Ariketa.php" method="get">
            <label for="aldatu">Sartu aldatu nahi duzun produktuaren Id-a:</label><br>
            <input type="text" name="aldatu" id="aldatu" placeholder="sartu Id-a" /><br>
            <input type="text" name="izena1" id="izena1" placeholder="sartu izena" /><br>
            <input type="text" name="mota1" id="mota1" placeholder="sartu mota" /><br>
            <input type="text" name="prezioa1" id="prezioa1" placeholder="sartu prezioa" />
            <button class="fa fa-pencil" aria-hidden="true" id="aldatu"></button><br>
        </form>

    </form>

    <?php

    if (isset($_GET["izena"]) && isset($_GET["mota"]) && isset($_GET["prezioa"])) {

        $sql = "insert into produktuak (izena, mota, prezioa) values ( '$izena', '$mota', '$prezioa');";
        if ($conn->query($sql) === TRUE) {
            echo "Insert-a ondo egin da";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    if (isset($_GET["id"])) {
        $sql1 = "DELETE FROM produktuak WHERE idProduktua = ?";
        $stmt = $conn->prepare($sql1);
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo "Produktua egoki kendu da.";
        } else {
            echo "Produktua kentzerakoan errore bat izan da. " . $conn->error;

        }
        $stmt->close();
    }
    if (isset($_GET["aldatu"])) {
        $sql2 = "update produktuak set izena ='$izena1', mota ='$mota1', prezioa='$prezioa' where aldatu = '$aldatu' ";
        $stmt2 = $conn->prepare($sql1);
        $stmt2->bind_param("i", $aldatu);

        if ($stmt2 ->execute()) {
            echo "Produktua egoki aldatu da.";
        } else {
            echo "Errore bat izan da produktua aldatzean " . $conn->error;

        }
        $stmt->close();
    }

    ?>
</body>

</html>
<?php
$query = "select * from produktuak where mota LIKE '%$filtratu%' or izena LIKE'%$filtratu%'";
$result2 = $conn->query(query: $query);
if ($result2->num_rows > 0) {
    //lerro bakoitzean dagoen data begiratzeko
    while ($row = $result2->fetch_assoc()) {
        echo "<table>";
        echo "<tr>";
        echo "<td>" . $row["idproduktua"] . "</td>" . "<td>" . $row["izena"] . "</td>" . "<td>" . $row["mota"] . "</td>" . "<td>" . $row["prezioa"] . "</td>";
        echo "</tr>";
        echo "</table>";
    }
}

$conn->close();
?>