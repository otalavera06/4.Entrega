-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: ml4entrega
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `produktuak`
--

DROP TABLE IF EXISTS `produktuak`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produktuak` (
  `idproduktua` int NOT NULL AUTO_INCREMENT,
  `izena` varchar(45) DEFAULT NULL,
  `mota` varchar(45) DEFAULT NULL,
  `prezioa` int DEFAULT NULL,
  PRIMARY KEY (`idproduktua`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `produktuak`
--

LOCK TABLES `produktuak` WRITE;
/*!40000 ALTER TABLE `produktuak` DISABLE KEYS */;
INSERT INTO `produktuak` VALUES (1,'Adidas Ultraboost 22','Kirolerako Zapatillak',160),(2,'Amazon Echo Dot','Audio aparato adimenduna',45),(3,'Apple Watch Series 9','Erloju adimenduna',369),(5,'Bose QuietComfort 45','Isolamendu aktibodun aurikularrak',309),(6,'Canon EOS Rebel T8i','Reflex Kamera',699),(7,'Dell XPS 13','Ordenagailu eramangarria',999),(8,'Dyson V15 Detect','Xurgagailua',649),(9,'Fitbit Charge 5','Adimendun pultsera',139),(10,'Google Nest Hub','Audio aparato adimenduna',79),(11,'GoPro HERO11 Black','Kamara',369),(12,'H&M Black Turtleneck Sweater','Arropa',25),(13,'Instant Pot Duo 7-en-1','Presio-aparatua',80),(14,'iPhone 15','Mugikorra',1039),(15,'KitchenAid Stand Mixer','Bateatzaile elektrikoa',359),(16,'Le Creuset Dutch Oven','Burdinezko labea',350),(17,'Levi\'s 501 Original Fit Jeans','Arropa',55),(18,'LG 55\" OLED TV','Telebista',1299),(19,'MacBook Air M2','Ordenagailu eramangarria',1099),(20,'Nespresso VertuoPlus','Kafegailua',150),(21,'Nike Air Max 270','Kirolerako Zapatillak',135),(22,'Nintendo Switch','Bideojoko kontsola',279),(23,'Ray-Ban Aviator','Betaurrekoak',160),(24,'Return to Tiffany Heart Tag Necklace','Bitxiak',210),(25,'Roomba i7+','Robot garbitzailea',749),(26,'Samsung 65\' QLED TV','Telebista',1199),(27,'Samsung Galaxy S23','Mugikorra',849),(28,'Seiko 5 Automatic Watch','Erloju automatikoa',89),(29,'Sony PlayStation 5','Bideojoko kontsola',459),(30,'Sony WH-1000XM5','Isolamendu aktibodun aurikularrak',379),(31,'TCL 50\" 4K UHD Roku TV','Telebista',289);
/*!40000 ALTER TABLE `produktuak` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-30 19:16:43
