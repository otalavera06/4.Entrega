<!DOCTYPE html>
<html lang="eu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editatu Produktua</title>
    <link rel="stylesheet" href="1ariketa.css">
</head>

<body>
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "1MG2024";
    $dbname = "ml";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Errorea konektatzean: " . $conn->connect_error);
    }

    if (isset($_POST['izena'], $_POST['mota'], $_POST['prezioa'])) {
        $izena = $_POST['izena'];
        $mota = $_POST['mota'];
        $prezioa = $_POST['prezioa'];

        
        $sql = "UPDATE produktuak SET mota = '$mota', prezioa = '$prezioa' WHERE izena = '$izena'";

        if ($conn->query($sql) === TRUE) {
            echo "<p>Produktuaren informazioa eguneratu da!</p>";
        } else {
            echo "<p>Errorea informazioa eguneratzen: " . $conn->error . "</p>";
        }
    } else {
        echo "<p>Formularioko datuak ez dira zuzenean jaso.</p>";
    }

    $conn->close();
    ?>
    <h1>Editatu Produktua</h1>
    <form action="editatu.php" method="POST">
        <label for="izena">Izena:</label>
        <input type="text" id="izena" name="izena" required>
        <br>

        <label for="mota">Mota:</label>
        <select id="mota" name="mota" required>
            <option value="Portatil">Portatil</option>
            <option value="Kontsola">Kontsola</option>
            <option value="Periferiko">Periferiko</option>
            <option value="Cascos">Cascos</option>
        </select>
        <br>

        <label for="prezioa">Prezioa:</label>
        <input type="number" id="prezioa" name="prezioa" required>
        <br>

        <input type="submit" value="Gorde">
    </form>
    <a href="1ariketa.php"><button type="button">Bueltatu horrira</button></a>
</body>

</html>